package SE_2024.ITS.entity;

public enum Status {
    NEW, ASSIGNED, FIXED, RESOLVED, CLOSED
}
