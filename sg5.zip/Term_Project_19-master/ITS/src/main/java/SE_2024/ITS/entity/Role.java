package SE_2024.ITS.entity;

public enum Role {
    PROJECTLEADER, DEVELOPER, TESTER
}
