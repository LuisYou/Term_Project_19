package SE_2024.ITS.controller;

public class SignupForm {

}
