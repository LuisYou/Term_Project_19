package SE_2024.ITS.controller;

import org.springframework.security.web.WebAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class loginController {

	@RequestMapping("/login*")
	public String login(
		@ModelAttribute("user") String user,
		@RequestAttribute(name = WebAttributes.AUTHENTICATION_EXCEPTION, required = false) Exception exception,
		Model model
	) {
		model.addAttribute("user", user);

		if (exception != null) {
			model.addAttribute("message", exception.getMessage());
		}

		return "login";
	}
}