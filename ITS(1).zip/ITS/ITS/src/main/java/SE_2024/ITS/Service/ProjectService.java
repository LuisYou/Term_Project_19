package SE_2024.ITS.Service;

public interface ProjectService {
}
