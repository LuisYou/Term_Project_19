package SE_2024.ITS.dto;

public class ProjectDto {
}
