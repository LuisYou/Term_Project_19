package SE_2024.ITS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsApplicationTests {

	@Test
	void contextLoads() {
	}

}
