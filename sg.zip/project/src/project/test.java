package project;

public class test {
	public class User {
	    private String id;
	    private String name;
	    private String email;
	    private Role role; // Enum: ADMIN, PL, DEVELOPER, TESTER
	    // getters and setters
	}
	
   public class Issue {
	    private String id;
	    private String title;
	    private String description;
	    private User reporter;
	    private LocalDateTime reportedDate;
	    private User fixer;
	    private User assignee;
	    private Priority priority; // Enum: BLOCKER, CRITICAL, MAJOR, MINOR, TRIVIAL
	    private Status status; // Enum: NEW, ASSIGNED, RESOLVED, CLOSED, REOPENED
	    private List<Comment> comments;
	    // getters and setters
	}
   
   public class Comment {
	    private String id;
	    private User author;
	    private LocalDateTime date;
	    private String content;
	    // getters and setters
	}
   
   public class Project {
	    private String id;
	    private String name;
	    private List<User> users;
	    private List<Issue> issues;
	    // getters and setters
	}
   
   public class IssueManager {
	    private PersistenceManager persistenceManager;
	    public void createIssue(Project project, String title, String description, User reporter) {
	        // implementation
	    }
	    public void updateIssue(Project project, Issue issue) {
	        // implementation
	    }
	    public List<Issue> searchIssues(Project project, SearchCriteria criteria) {
	        // implementation
	    }
	    public void addComment(Project project, String issueId, Comment comment) {
	        // implementation
	    }
	    // Other methods for issue management
	}
   public interface PersistenceManager {
	    void saveIssue(Project project, Issue issue);
	    Issue loadIssue(Project project, String id);
	    List<Issue> loadAllIssues(Project project);
	    void saveUser(User user);
	    User loadUser(String id);
	    void saveProject(Project project);
	    Project loadProject(String id);
	}
   public class FilePersistenceManager implements PersistenceManager {
	    // File system based implementation
	}
   public class IssueRecommender {
	    public List<User> recommendAssignees(Project project, Issue issue) {
	        // Recommendation logic based on past issue data
	    }
	}
   public interface UI {
	    void display();
	}

	public class SwingUI implements UI {
	    // Swing based implementation
	}

	public class WebUI implements UI {
	    // Web based implementation
	}
   
}

