package project;

public class testCreateIssue {
	IssueManager manager = new IssueManager(new FilePersistenceManager());
    User reporter = new User("u123", "John Doe", "john@example.com", Role.TESTER);
    Project project = new Project("p1", "project1");
    manager.createIssue(project, "Issue Title", "Issue Description", reporter);
    Issue issue = manager.searchIssues(project, new SearchCriteria().setTitle("Issue Title")).get(0);
    assertEquals("Issue Title", issue.getTitle());
    assertEquals("Issue Description", issue.getDescription());
    assertEquals(reporter, issue.getReporter());
}
}
