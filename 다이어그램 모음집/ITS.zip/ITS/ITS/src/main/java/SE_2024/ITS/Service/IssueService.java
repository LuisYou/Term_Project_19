package SE_2024.ITS.Service;

import SE_2024.ITS.entity.Issue;

public interface IssueService {
    void saveIssue(Issue issue);
    Issue getIssueById(int id);
    Issue getIssueByTitle(String title);
    Issue getIssueByAssignee(String assignee);
    Issue getIssueByStatus(String status);
}
