package SE_2024.ITS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class IssueDto {
    private int id;
    private String title;
    private LocalDate reportedDate;
    private String reporter;
    private LocalDate fixedDate;
    private String fixer;
    private boolean assigned;
    private String assignee;
    private List<String> comments;
    private String status;
    private int priority;
}