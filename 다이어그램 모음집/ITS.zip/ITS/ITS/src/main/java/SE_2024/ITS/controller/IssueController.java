package SE_2024.ITS.controller;

import SE_2024.ITS.dto.IssueDto;
import SE_2024.ITS.entity.Issue;
import SE_2024.ITS.Service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/issues")
public class IssueController {

    private final IssueService issueService;

    @Autowired
    public IssueController(IssueService issueService) {
        this.issueService = issueService;
    }

    @PostMapping("/create")
    public void createIssue(@RequestBody IssueDto issueDto) {
        Issue issue = new Issue();
        issue.setTitle(issueDto.getTitle());
        issue.setReportedDate(issueDto.getReportedDate());
        issue.setReporter(issueDto.getReporter());
        issue.setAssigned(issueDto.isAssigned());
        issue.setAssignee(issueDto.getAssignee());
        issue.setStatus(issueDto.getStatus());
        issue.setPriority(issueDto.getPriority());
        // Set other issue details as needed
        issueService.saveIssue(issue);
    }

    @GetMapping("/{id}")
    public IssueDto getIssueById(@PathVariable int id) {
        Issue issue = issueService.getIssueById(id);
        IssueDto issueDto = new IssueDto();
        issueDto.setId(issue.getId());
        issueDto.setTitle(issue.getTitle());
        issueDto.setReportedDate(issue.getReportedDate());
        issueDto.setReporter(issue.getReporter());
        issueDto.setAssigned(issue.isAssigned());
        issueDto.setAssignee(issue.getAssignee());
        issueDto.setStatus(issue.getStatus());
        issueDto.setPriority(issue.getPriority());
        // Set other issue details as needed
        return issueDto;
    }
}