package SE_2024.ITS.Service;

import SE_2024.ITS.entity.Issue;
import SE_2024.ITS.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IssueServiceImpl implements IssueService {

    private final IssueRepository issueRepository;

    @Autowired
    public IssueServiceImpl(IssueRepository issueRepository) {
        this.issueRepository = issueRepository;
    }

    @Override
    public void saveIssue(Issue issue) {
        issueRepository.save(issue);
    }

    @Override
    public Issue getIssueById(int id) {
        return issueRepository.findById(id);
    }

    @Override
    public Issue getIssueByTitle(String title) {
        return issueRepository.findByTitle(title);
    }

    @Override
    public Issue getIssueByAssignee(String assignee) {
        return issueRepository.findByAssignee(assignee);
    }

    @Override
    public Issue getIssueByStatus(String status) {
        return issueRepository.findByStatus(status);
    }
}