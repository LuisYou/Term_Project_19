package SE_2024.ITS.controller;

import SE_2024.ITS.dto.ProjectDto;
import SE_2024.ITS.entity.Project;
import SE_2024.ITS.Service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/projects")
public class ProjectController {

    private final ProjectService projectService;

    @Autowired
    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @PostMapping("/create")
    public void createProject(@RequestBody ProjectDto projectDto) {
        Project project = convertToEntity(projectDto);
        projectService.saveProject(project);
    }

    @GetMapping("/{id}")
    public ProjectDto getProjectById(@PathVariable int id) {
        Project project = projectService.getProjectById(id);
        return convertToDto(project);
    }

    @GetMapping("/title/{title}")
    public ProjectDto getProjectByTitle(@PathVariable String title) {
        Project project = projectService.getProjectByTitle(title);
        return convertToDto(project);
    }

    @GetMapping("/all")
    public List<ProjectDto> getAllProjects() {
        List<Project> projects = projectService.getAllProjects();
        return projects.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    private ProjectDto convertToDto(Project project) {
        return new ProjectDto(
                project.getProjectId(),
                project.getProjectName(),
                project.getCreatedDate(),
                project.getExpiredDate()
        );
    }

    private Project convertToEntity(ProjectDto projectDto) {
        return new Project(
                projectDto.getProjectId(),
                projectDto.getProjectName(),
                projectDto.getCreatedDate(),
                projectDto.getExpiredDate(),
                null // Assuming issues are not included in the DTO
        );
    }
}