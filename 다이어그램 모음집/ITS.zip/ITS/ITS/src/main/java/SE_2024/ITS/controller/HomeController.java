package SE_2024.ITS.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import SE_2024.ITS.dto.IssueDto;
import SE_2024.ITS.dto.UserDto;
import SE_2024.ITS.entity.Issue;
import SE_2024.ITS.entity.User;
import SE_2024.ITS.Service.IssueService;
import SE_2024.ITS.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/home")
public class HomeController {

    private final UserService userService;
    private final IssueService issueService;

    @Autowired
    public HomeController(UserService userService, IssueService issueService) {
        this.userService = userService;
        this.issueService = issueService;
    }

    @GetMapping("/user/{id}")
    public User getUserById(@PathVariable int id) {
        return userService.getUserById(id);
    }

    @GetMapping("/issue/{id}")
    public Issue getIssueById(@PathVariable int id) {
        return issueService.getIssueById(id);
    }
}