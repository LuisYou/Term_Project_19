package SE_2024.ITS.controller;

import SE_2024.ITS.dto.UserDto;
import SE_2024.ITS.entity.User;
import SE_2024.ITS.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/create")
    public void createUser(@RequestBody UserDto userDto) {
        User user = new User();
        user.setUserid(userDto.getUserid());
        user.setPassword(userDto.getPassword());
        user.setCreatedDate(userDto.getCreatedDate());
        user.setName(userDto.getName());
        user.setBirth(userDto.getBirth());
        user.seteMail(userDto.geteMail()); 
        user.setAddress(userDto.getAddress());
        user.setRole(userDto.getRole());
        // Set other user details as needed
        userService.saveUser(user);
    }

    @GetMapping("/{id}")
    public UserDto getUserById(@PathVariable int id) {
        User user = userService.getUserById(id);
        UserDto userDto = new UserDto();
        userDto.setUserid(user.getUserid());
        userDto.setPassword(user.getPassword());
        userDto.setCreatedDate(user.getCreatedDate());
        userDto.setName(user.getName());
        userDto.setBirth(user.getBirth());
        userDto.seteMail(user.geteMail()); 
        userDto.setAddress(user.getAddress());
        userDto.setRole(user.getRole());
        // Set other user details as needed
        return userDto;
    }
}