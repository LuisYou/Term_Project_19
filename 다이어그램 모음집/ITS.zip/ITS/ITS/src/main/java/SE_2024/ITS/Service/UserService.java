package SE_2024.ITS.Service;

import SE_2024.ITS.entity.User;

public interface UserService {
    void saveUser(User user);
    User getUserById(int id);
    User getUserByName(String name);
    User getUserByRole(String role);
}