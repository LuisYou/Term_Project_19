package SE_2024.ITS.Service;

import SE_2024.ITS.entity.Project;

import java.util.List;
public interface ProjectService {
    void saveProject(Project project);
    Project getProjectById(int id);
    Project getProjectByTitle(String title);
    List<Project> getAllProjects();

}
