package SE_2024.ITS;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import SE_2024.ITS.controller.HomeController;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class ItsApplicationTests {

    @Autowired
    private HomeController homeController;

    @Test
    void contextLoads() {
        assertNotNull(homeController);
    }
}