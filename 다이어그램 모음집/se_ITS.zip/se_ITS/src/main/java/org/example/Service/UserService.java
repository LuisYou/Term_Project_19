package org.example.Service;

public class UserService {
}
