package org.example.Model;

public class Status {
    private String statusName;
    public String getStatusName(){
        return statusName;
    }
    public void setStatusName(String statusName){
        this.statusName = statusName;
    }
}
