package org.example.Domain;

import org.example.Model.Issue;

public class ProjectLeader extends User{
    public Issue assignDev(){
        return null;
    }
    public Issue changeState(){
        return null;
    }

}
