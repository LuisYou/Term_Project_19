package org.example.Model;

public class Comments {
    private Long commentsId;
    private String comment;
    public Long getCommentsId(){
        return commentsId;
    }
    public void setCommentsId(Long commentsId){
        this.commentsId = commentsId;
    }
    public String getComment(){
        return comment;
    }
    public void setComment(String comment){
        this.comment = comment;
    }

}
