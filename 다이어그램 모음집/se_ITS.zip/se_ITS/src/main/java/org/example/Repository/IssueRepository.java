package org.example.Repository;

import org.example.Model.Issue;

import java.util.List;
import java.util.Optional;

public interface IssueRepository {
    Issue save(Issue issue);
    Optional<Issue> findById(Long id);
    Optional<Issue> findByTitle(String title);
    List<Issue> findAll();
}
