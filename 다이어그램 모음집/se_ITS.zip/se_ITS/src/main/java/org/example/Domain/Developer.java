package org.example.Domain;

import org.example.Model.Comments;
import org.example.Model.Issue;

public class Developer extends User{
    public Issue changeState(){
        return null;
    }
    public Issue createComment(Comments comment){
        return null;
    }
}
