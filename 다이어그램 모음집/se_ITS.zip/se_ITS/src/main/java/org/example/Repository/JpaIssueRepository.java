package org.example.Repository;

import jakarta.persistence.EntityManager;
import org.example.Model.Issue;

import java.util.List;
import java.util.Optional;

public class JpaIssueRepository implements IssueRepository{
    private final EntityManager em;
        this.em = em;
    }

    @Override
    public Issue save(Issue issue) {
        em.persist(issue);
        return issue;
    }

    @Override
    public Optional<Issue> findById(Long id) {
        Issue issue = em.find(Issue.class, id);
        return Optional.ofNullable(issue);
    }

    @Override
    public Optional<Issue> findByTitle(String title) {
        List<Issue> result = em.createQuery("select i from Issue i where i.title = :title", Issue.class).setParameter("title", title).getResultList();
        return result.stream().findAny();
    }

    @Override
    public List<Issue> findAll() {
        List<Issue> result = em.createQuery("select i from Issue i", Issue.class).getResultList();
        return result;
    }
}
