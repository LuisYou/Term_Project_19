package org.example.Service;

import org.example.Model.Issue;
import org.example.Repository.IssueRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Transactional
public class IssueService {
    private IssueRepository issueRepository;
    public IssueService(IssueRepository issueRepository){
        this.issueRepository = issueRepository;
    }
    public Long registIssue(Issue issue){
        validateDuplicateIssue(issue);
        issueRepository.save(issue);
        return issue.getId();
    }
    private void validateDuplicateIssue(Issue issue){
        issueRepository.findByTitle(issue.getTitle())
                .ifPresent(m->{
                    throw new IllegalStateException("이미 생성된 이슈입니다.");
                });
    }
    public static List<Issue> findIssue(){
        return issueRepository.findAll();
    }
    public Optional<Issue> findOneIssue(String title){
        return issueRepository.findByTitle(title);
    }
    public Optional<Issue> findOneIssue(Long id){
        return issueRepository.findById(id);
    }
    public void deletedById(Long id){
        issueRepository.deletedById(id);
    }
}
