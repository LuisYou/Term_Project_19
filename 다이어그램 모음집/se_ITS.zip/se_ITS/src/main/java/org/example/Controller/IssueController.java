package org.example.Controller;

import org.example.Model.Issue;
import org.example.Service.IssueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class IssueController {
    private final IssueService issueService;
    @Autowired
    public IssueController(IssueService issueService){
        this.issueService = issueService;
    }
    @GetMapping("issue/new")
    public String createForm(){
        return"issue/createIssueForm";
    }
    @PostMapping("issue/new")
    public String create(IssueForm form){
        Issue issue = new Issue();
        issue.setTitle(form.getTitle());

        System.out.println("issue = " + issue.getTitle());
        issueService.registIssue(issue);
        return "redirect:/";
    }
    @GetMapping("/issue")
    public String list(Model model){
        List<Issue> issue = IssueService.findIssue();
        model.addAttribute("issue", issue);
        return"issue/issueList";

    }

}
