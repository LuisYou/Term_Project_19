package org.example.Domain;

public class Tester extends User{

}
