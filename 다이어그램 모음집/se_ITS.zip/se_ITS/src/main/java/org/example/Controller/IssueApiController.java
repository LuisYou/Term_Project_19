package org.example.Controller;

import org.example.Model.Issue;
import org.example.Service.IssueService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class IssueApiController {
    private IssueService issueService;
    @PostMapping("/create")
    public Long createPost(@RequestBody Issue requestDto){
        return issueService.registIssue(requestDto);
    }
}
