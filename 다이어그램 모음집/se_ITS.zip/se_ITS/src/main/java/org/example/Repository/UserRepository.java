package org.example.Repository;

public interface UserRepository {
}
