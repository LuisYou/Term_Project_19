package org.example.Dto;

import lombok.Getter;
import org.example.Domain.User;
import org.example.Model.Issue;

import java.time.LocalDateTime;

@Getter
public class IssueListResponseDto {
    private Long id;
    private String title;
    private User assignee;
    private LocalDateTime modifiedDate;

    public IssueListResponseDto(Issue entity){
        this.id = entity.getId();
        this.title = entity.getTitle();
        this.assignee = entity.getAssignee();
    }

}
