package org.example.Domain;

import org.example.Model.Issue;

public interface UserIssueTracking {
    public Issue BrowseIssue();
}
