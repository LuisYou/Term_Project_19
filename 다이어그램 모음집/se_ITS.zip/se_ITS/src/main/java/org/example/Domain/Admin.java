package org.example.Domain;

public class Admin extends User{
    public void createUser(){

    }
    public void createProject(){

    }
}
