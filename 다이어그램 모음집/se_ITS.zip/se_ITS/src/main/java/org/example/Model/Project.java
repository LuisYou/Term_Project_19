package org.example.Model;

import org.example.Domain.User;

import java.util.Date;

public class Project {
    private int projectId;
    private String title;
    private Date startedDate;
    private Date expiredDate;
    private User assignee;
    private int priority;
}
