package org.example.Controller;

public class IssueForm {
    public String title;
    public String getTitle(){
        return title;
    }
    public void setTitle(String title){
        this.title = title;
    }
}
