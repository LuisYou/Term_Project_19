package org.example.Service;

import jakarta.persistence.EntityManager;
import org.example.Repository.IssueRepository;
import org.example.Repository.JpaIssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
    private EntityManager em;
    @Autowired
    public SpringConfig(EntityManager em){
        this.em = em;
    }
    @Bean
    public IssueService issueService(){
        return new IssueService(issueRepository());
    }
    @Bean
    public IssueRepository issueRepository(){
        return new JpaIssueRepository();
    }

}
